export const environment = {
  production: false,
  books_service_base_url: "http://localhost:3000",
  users_service_base_url: "http://localhost:3000/users",
  
  environment: "development"
};

