export const environment = {
  production: true,
  books_service_base_url: "http://localhost:3000",
  users_service_base_url: "http://localhost:3000/users",

  environment: "production"
};

